package com.example.glucose_control

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
