import 'main.dart';

class LoginTexts {
  static const String target = 'Treatment Regiment';
  static const String title = 'Đăng nhập';
  static const String labelEmail = 'Email';
  static const String hintTextEmail = 'Nhập email';
  static const String labelPass = 'Mật khẩu';
  static const String hintTextPass = 'Nhập mật khẩu';
  static const String rememberPass = 'Lưu mật khẩu';
  static const String forgotPass = 'Quên mật khẩu?';
  static const String emptydata = 'Data rỗng ';
  static const String EmailErr = 'Email không đúng định dạng';
  static const String PassErr = 'Password ít nhất 8 ký tự gồm chữ hoa, chữ thường và số';
  static const String titleItem1 = 'Nhập số liệu';
  static const String titleItem2 = 'Quản lý bệnh nhân';
  static const String titleItem3 = 'Trình tạo mã QR';
  static const String titleItem4 = 'Thông tin ứng dụng';
}
