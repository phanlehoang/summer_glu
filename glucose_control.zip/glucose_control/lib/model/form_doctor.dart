class FeedbackForm {

  String _name;
  String _email;
  String _mobileNo;
  String _amoutGlu;
  String _feedback;

  FeedbackForm(this._name, this._email, this._feedback, this._mobileNo, this._amoutGlu);

  // Method to make GET parameters.
  String toParams() =>
      "?name=$_name&email=$_email&mobileNo=$_mobileNo&feedback=$_feedback";


}