import 'package:flutter/material.dart';
import 'package:glucose_control/const.dart';
import 'package:glucose_control/model/enterform_doctor.dart';

class Login_intro extends StatefulWidget {
  @override
  _Login_introState createState() => _Login_introState();
}

class _Login_introState extends State<Login_intro> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
          appBar: AppBar(
            centerTitle: true,
            title: Text(LoginTexts.target),
          ),
          body: Container(
            padding: EdgeInsets.all(100),
            child: Center(
                child: Column(children: <Widget>[
              Container(
                margin: EdgeInsets.all(45),
                child: FlatButton(
                  child: Text(
                    'Login as Doctor',
                    style: TextStyle(fontSize: 20.0),
                  ),
                  color: Colors.cyan,
                  textColor: Colors.black,
                    onPressed: () {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) => LoginScr()));
                    },
                ),
              ),
              Container(
                margin: EdgeInsets.all(45),
                child: FlatButton(
                  child: Text(
                    'Login as Victim',
                    style: TextStyle(fontSize: 20.0),
                  ),
                  color: Colors.cyan,
                  textColor: Colors.black,
                  onPressed: () {},
                ),
              ),
            ])),
          )),
    );
  }
}
