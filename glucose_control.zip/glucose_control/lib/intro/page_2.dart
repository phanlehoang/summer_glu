import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:glucose_control/const.dart';
import 'package:glucose_control/login/login_intro.dart';

class FinalPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<FinalPage> {
  @override
  Widget build(BuildContext context) {
    //Now we need multiple widgets into a parent = "Container" widget
    Widget titleSection = new Container(
      padding: const EdgeInsets.all(30.0), //Top, Right, Bottom, Left
      child: new Row(
        children: <Widget>[
          new Expanded(
            child: new Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                new Container(
                  padding: const EdgeInsets.only(bottom: 10.0),
                  child: new Text("Delivery Arrived",
                      style: new TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 32)),
                ),
                //Need to add space below this Text ?
                new Text(
                  "order is arrived at your Place",
                  style: new TextStyle(color: Colors.grey[850], fontSize: 16.0),
                ),
              ],
            ),
          ),
        ],
      ),
    );

    //build function returns a "Widget"
    return MaterialApp(
        title: "",
        home: new Scaffold(
          appBar: AppBar(
              centerTitle: true,
              backgroundColor: Colors.white,
              titleTextStyle: TextStyle(color: Colors.black, fontSize: 40),
              title: Text(LoginTexts.target)),
          body: new ListView(
            children: <Widget>[
              new Image.asset('assets/images/insulin.jpg', fit: BoxFit.cover),
              //You can add more widget bellow
              titleSection
            ],
          ),
          floatingActionButton: Theme(
            data: Theme.of(context).copyWith(
                floatingActionButtonTheme: FloatingActionButtonThemeData(
                    extendedSizeConstraints:
                        BoxConstraints.tightFor(height: 60, width: 200))),
            child: FloatingActionButton.extended(
              shape: RoundedRectangleBorder(),
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => Login_intro()));
              },
              backgroundColor: Colors.green,
              label: Text('Next'),
            ),
          ),
          floatingActionButtonLocation:
              FloatingActionButtonLocation.centerFloat,
        )); //Widget with "Material design"
  }
}
